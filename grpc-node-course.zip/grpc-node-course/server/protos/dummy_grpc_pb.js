// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var protos_dummy_pb = require('../protos/dummy_pb.js');


var DummyServiceService = exports.DummyServiceService = {
};

exports.DummyServiceClient = grpc.makeGenericClientConstructor(DummyServiceService);
