# grpc-node-course

To get started, make sure to install the NPM dependencies:

`$ npm install`
