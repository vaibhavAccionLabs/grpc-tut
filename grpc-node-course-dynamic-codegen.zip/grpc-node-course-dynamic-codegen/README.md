# grpc-node-course-dynamic-codegen
Dynamic Codegen with gRPC Nodejs - 

Install the following modules:

`npm install grpc`

`npm install @grpc/proto-loader`


